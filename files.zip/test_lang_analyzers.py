#!/usr/bin/env python3
"""
Tests for lang_analyzers.py - Language-specific Resilience Analyzers

Tests cover:
- LanguageResilienceMetrics dataclass
- Base analyzer functionality
- Language-specific analyzers (Python, JavaScript, Go, Java, C++)
- Analyzer registry and factory functions
"""

import pytest
import tempfile
from pathlib import Path

from lang_analyzers import (
    LanguageResilienceMetrics,
    BaseLanguageAnalyzer,
    PythonAnalyzer,
    JavaScriptAnalyzer,
    GoAnalyzer,
    JavaAnalyzer,
    CppAnalyzer,
    ANALYZER_REGISTRY,
    get_analyzer,
    analyze_file,
)


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture
def temp_dir():
    """Create a temporary directory for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


# =============================================================================
# DATA MODEL TESTS
# =============================================================================

class TestLanguageResilienceMetrics:
    """Tests for LanguageResilienceMetrics dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        metrics = LanguageResilienceMetrics()
        assert metrics.error_handlers == 0
        assert metrics.resource_guards == 0
        assert metrics.null_checks == 0
    
    def test_custom_values(self):
        """Test custom values."""
        metrics = LanguageResilienceMetrics(
            error_handlers=10,
            resource_guards=5,
            null_checks=20,
            logging_calls=15,
        )
        assert metrics.error_handlers == 10
        assert metrics.logging_calls == 15
    
    def test_extras_dict(self):
        """Test extras dictionary."""
        metrics = LanguageResilienceMetrics()
        assert isinstance(metrics.extras, dict)
        
        metrics.extras['custom_key'] = 'custom_value'
        assert metrics.extras['custom_key'] == 'custom_value'


# =============================================================================
# ANALYZER REGISTRY TESTS
# =============================================================================

class TestAnalyzerRegistry:
    """Tests for analyzer registry."""
    
    def test_registry_has_python(self):
        """Test that Python analyzer is registered."""
        assert '.py' in ANALYZER_REGISTRY
    
    def test_registry_has_javascript(self):
        """Test that JavaScript analyzers are registered."""
        assert '.js' in ANALYZER_REGISTRY
        assert '.ts' in ANALYZER_REGISTRY
    
    def test_registry_has_go(self):
        """Test that Go analyzer is registered."""
        assert '.go' in ANALYZER_REGISTRY
    
    def test_registry_has_java(self):
        """Test that Java analyzer is registered."""
        assert '.java' in ANALYZER_REGISTRY
    
    def test_registry_has_cpp(self):
        """Test that C++ analyzers are registered."""
        assert '.cpp' in ANALYZER_REGISTRY
        assert '.hpp' in ANALYZER_REGISTRY


class TestGetAnalyzer:
    """Tests for get_analyzer factory function."""
    
    def test_get_python_analyzer(self):
        """Test getting Python analyzer."""
        analyzer = get_analyzer("test.py")
        assert analyzer is not None
        assert isinstance(analyzer, PythonAnalyzer)
    
    def test_get_javascript_analyzer(self):
        """Test getting JavaScript analyzer."""
        analyzer = get_analyzer("test.js")
        assert analyzer is not None
        assert isinstance(analyzer, JavaScriptAnalyzer)
    
    def test_get_go_analyzer(self):
        """Test getting Go analyzer."""
        analyzer = get_analyzer("test.go")
        assert analyzer is not None
        assert isinstance(analyzer, GoAnalyzer)
    
    def test_get_java_analyzer(self):
        """Test getting Java analyzer."""
        analyzer = get_analyzer("test.java")
        assert analyzer is not None
        assert isinstance(analyzer, JavaAnalyzer)
    
    def test_get_cpp_analyzer(self):
        """Test getting C++ analyzer."""
        analyzer = get_analyzer("test.cpp")
        assert analyzer is not None
        assert isinstance(analyzer, CppAnalyzer)
    
    def test_unknown_extension_returns_none(self):
        """Test that unknown extension returns None."""
        analyzer = get_analyzer("test.xyz")
        assert analyzer is None
    
    def test_handles_path_objects(self):
        """Test that Path objects are handled."""
        analyzer = get_analyzer(Path("test.py"))
        assert analyzer is not None


# =============================================================================
# PYTHON ANALYZER TESTS
# =============================================================================

class TestPythonAnalyzer:
    """Tests for PythonAnalyzer class."""
    
    def test_language_name(self):
        """Test language name."""
        analyzer = PythonAnalyzer()
        assert analyzer.LANGUAGE_NAME == "python"
    
    def test_detects_try_except(self):
        """Test detection of try-except blocks."""
        analyzer = PythonAnalyzer()
        code = '''
try:
    risky_operation()
except ValueError:
    handle_error()
'''
        metrics = analyzer.analyze(code, "test.py")
        assert metrics.error_handlers >= 1
    
    def test_detects_context_manager(self):
        """Test detection of context managers."""
        analyzer = PythonAnalyzer()
        code = '''
with open('file.txt') as f:
    content = f.read()
'''
        metrics = analyzer.analyze(code, "test.py")
        assert metrics.resource_guards >= 1
    
    def test_detects_logging(self):
        """Test detection of logging calls."""
        analyzer = PythonAnalyzer()
        code = '''
import logging
logger = logging.getLogger(__name__)
logger.info("Processing started")
logger.error("An error occurred")
'''
        metrics = analyzer.analyze(code, "test.py")
        assert metrics.logging_calls >= 2
    
    def test_detects_null_checks(self):
        """Test detection of null checks."""
        analyzer = PythonAnalyzer()
        code = '''
if value is None:
    return default
if other is not None:
    process(other)
'''
        metrics = analyzer.analyze(code, "test.py")
        assert metrics.null_checks >= 2
    
    def test_detects_assertions(self):
        """Test detection of assertions."""
        analyzer = PythonAnalyzer()
        code = '''
assert value > 0, "Value must be positive"
assert isinstance(data, dict)
'''
        metrics = analyzer.analyze(code, "test.py")
        assert metrics.assertions >= 2


# =============================================================================
# JAVASCRIPT ANALYZER TESTS
# =============================================================================

class TestJavaScriptAnalyzer:
    """Tests for JavaScriptAnalyzer class."""
    
    def test_language_name(self):
        """Test language name."""
        analyzer = JavaScriptAnalyzer()
        assert analyzer.LANGUAGE_NAME == "javascript"
    
    def test_detects_try_catch(self):
        """Test detection of try-catch blocks."""
        analyzer = JavaScriptAnalyzer()
        code = '''
try {
    riskyOperation();
} catch (error) {
    handleError(error);
}
'''
        metrics = analyzer.analyze(code, "test.js")
        assert metrics.error_handlers >= 1
    
    def test_detects_promise_catch(self):
        """Test detection of Promise catch handlers."""
        analyzer = JavaScriptAnalyzer()
        code = '''
fetch(url)
    .then(response => response.json())
    .catch(error => console.error(error));
'''
        metrics = analyzer.analyze(code, "test.js")
        # Should detect .catch()
        assert metrics is not None
    
    def test_detects_console_logging(self):
        """Test detection of console logging."""
        analyzer = JavaScriptAnalyzer()
        code = '''
console.log("Debug message");
console.error("Error occurred");
console.warn("Warning");
'''
        metrics = analyzer.analyze(code, "test.js")
        assert metrics.logging_calls >= 3
    
    def test_detects_null_checks(self):
        """Test detection of null checks."""
        analyzer = JavaScriptAnalyzer()
        code = '''
if (value === null) return;
if (other !== undefined) process(other);
const result = data ?? defaultValue;
'''
        metrics = analyzer.analyze(code, "test.js")
        assert metrics.null_checks >= 1


# =============================================================================
# GO ANALYZER TESTS
# =============================================================================

class TestGoAnalyzer:
    """Tests for GoAnalyzer class."""
    
    def test_language_name(self):
        """Test language name."""
        analyzer = GoAnalyzer()
        assert analyzer.LANGUAGE_NAME == "go"
    
    def test_detects_error_handling(self):
        """Test detection of Go error handling."""
        analyzer = GoAnalyzer()
        code = '''
result, err := doSomething()
if err != nil {
    return fmt.Errorf("failed: %w", err)
}
'''
        metrics = analyzer.analyze(code, "test.go")
        assert metrics.error_handlers >= 1
    
    def test_detects_defer(self):
        """Test detection of defer statements."""
        analyzer = GoAnalyzer()
        code = '''
func process() {
    f, _ := os.Open("file.txt")
    defer f.Close()
}
'''
        metrics = analyzer.analyze(code, "test.go")
        assert metrics.resource_guards >= 1
    
    def test_detects_logging(self):
        """Test detection of logging."""
        analyzer = GoAnalyzer()
        code = '''
log.Printf("Processing %s", item)
log.Fatal("Critical error")
'''
        metrics = analyzer.analyze(code, "test.go")
        assert metrics.logging_calls >= 2
    
    def test_detects_nil_checks(self):
        """Test detection of nil checks."""
        analyzer = GoAnalyzer()
        code = '''
if ptr == nil {
    return errors.New("nil pointer")
}
if result != nil {
    process(result)
}
'''
        metrics = analyzer.analyze(code, "test.go")
        assert metrics.null_checks >= 2


# =============================================================================
# JAVA ANALYZER TESTS
# =============================================================================

class TestJavaAnalyzer:
    """Tests for JavaAnalyzer class."""
    
    def test_language_name(self):
        """Test language name."""
        analyzer = JavaAnalyzer()
        assert analyzer.LANGUAGE_NAME == "java"
    
    def test_detects_try_catch(self):
        """Test detection of try-catch blocks."""
        analyzer = JavaAnalyzer()
        code = '''
try {
    riskyOperation();
} catch (IOException e) {
    logger.error("IO error", e);
}
'''
        metrics = analyzer.analyze(code, "Test.java")
        assert metrics.error_handlers >= 1
    
    def test_detects_try_with_resources(self):
        """Test detection of try-with-resources."""
        analyzer = JavaAnalyzer()
        code = '''
try (FileInputStream fis = new FileInputStream("file.txt")) {
    // process file
}
'''
        metrics = analyzer.analyze(code, "Test.java")
        assert metrics.resource_guards >= 1
    
    def test_detects_logging(self):
        """Test detection of logging."""
        analyzer = JavaAnalyzer()
        code = '''
logger.info("Processing started");
logger.error("An error occurred");
log.debug("Debug info");
'''
        metrics = analyzer.analyze(code, "Test.java")
        assert metrics.logging_calls >= 3
    
    def test_detects_null_checks(self):
        """Test detection of null checks."""
        analyzer = JavaAnalyzer()
        code = '''
if (value == null) {
    return defaultValue;
}
Objects.requireNonNull(param);
Optional.ofNullable(data);
'''
        metrics = analyzer.analyze(code, "Test.java")
        assert metrics.null_checks >= 1


# =============================================================================
# C++ ANALYZER TESTS
# =============================================================================

class TestCppAnalyzer:
    """Tests for CppAnalyzer class."""
    
    def test_language_name(self):
        """Test language name."""
        analyzer = CppAnalyzer()
        assert analyzer.LANGUAGE_NAME == "cpp"
    
    def test_detects_try_catch(self):
        """Test detection of try-catch blocks."""
        analyzer = CppAnalyzer()
        code = '''
try {
    riskyOperation();
} catch (const std::exception& e) {
    std::cerr << e.what() << std::endl;
}
'''
        metrics = analyzer.analyze(code, "test.cpp")
        assert metrics.error_handlers >= 1
    
    def test_detects_raii_guards(self):
        """Test detection of RAII guards."""
        analyzer = CppAnalyzer()
        code = '''
std::lock_guard<std::mutex> lock(mutex);
std::unique_ptr<Resource> ptr(new Resource());
auto guard = make_scope_guard([] { cleanup(); });
'''
        metrics = analyzer.analyze(code, "test.cpp")
        assert metrics.resource_guards >= 1
    
    def test_detects_null_checks(self):
        """Test detection of null checks."""
        analyzer = CppAnalyzer()
        code = '''
if (ptr == nullptr) {
    return;
}
if (other != NULL) {
    process(other);
}
'''
        metrics = analyzer.analyze(code, "test.cpp")
        assert metrics.null_checks >= 2


# =============================================================================
# ANALYZE_FILE FUNCTION TESTS
# =============================================================================

class TestAnalyzeFile:
    """Tests for analyze_file function."""
    
    def test_analyze_python_file(self, temp_dir):
        """Test analyzing a Python file."""
        py_file = Path(temp_dir) / "test.py"
        py_file.write_text('''
try:
    risky()
except Exception:
    pass
''')
        
        metrics = analyze_file(str(py_file))
        assert metrics is not None
        assert metrics.error_handlers >= 1
    
    def test_analyze_javascript_file(self, temp_dir):
        """Test analyzing a JavaScript file."""
        js_file = Path(temp_dir) / "test.js"
        js_file.write_text('''
try {
    risky();
} catch (e) {
    console.error(e);
}
''')
        
        metrics = analyze_file(str(js_file))
        assert metrics is not None
    
    def test_analyze_nonexistent_file(self):
        """Test analyzing non-existent file returns None."""
        metrics = analyze_file("/nonexistent/file.py")
        assert metrics is None
    
    def test_analyze_unknown_extension(self, temp_dir):
        """Test analyzing file with unknown extension."""
        unknown_file = Path(temp_dir) / "test.xyz"
        unknown_file.write_text("content")
        
        metrics = analyze_file(str(unknown_file))
        assert metrics is None


# =============================================================================
# EDGE CASES
# =============================================================================

class TestEdgeCases:
    """Tests for edge cases."""
    
    def test_empty_file(self):
        """Test analyzing empty file."""
        analyzer = PythonAnalyzer()
        metrics = analyzer.analyze("", "test.py")
        
        assert metrics is not None
        assert metrics.error_handlers == 0
    
    def test_comments_only(self):
        """Test file with only comments."""
        analyzer = PythonAnalyzer()
        code = '''
# This is a comment
# Another comment
"""
Docstring
"""
'''
        metrics = analyzer.analyze(code, "test.py")
        assert metrics is not None
    
    def test_syntax_error_content(self):
        """Test content with syntax errors."""
        analyzer = PythonAnalyzer()
        code = '''
def broken(
    # Missing closing paren
    pass
'''
        # Should not crash
        metrics = analyzer.analyze(code, "test.py")
        assert metrics is not None
    
    def test_unicode_content(self):
        """Test content with unicode characters."""
        analyzer = PythonAnalyzer()
        code = '''
# 日本語コメント
def greet():
    return "こんにちは 🎉"
'''
        metrics = analyzer.analyze(code, "test.py")
        assert metrics is not None
    
    def test_very_long_line(self):
        """Test file with very long lines."""
        analyzer = PythonAnalyzer()
        code = "x = '" + "a" * 10000 + "'"
        
        metrics = analyzer.analyze(code, "test.py")
        assert metrics is not None


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
