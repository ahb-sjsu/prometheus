#!/usr/bin/env python3
"""
Tests for shield_analyzer.py - Aegis Resilience Pattern Analyzer

Tests cover:
- Data models (ErrorHandlingMetrics, TimeoutMetrics, etc.)
- PatternDetector class
- Aegis analyzer class
- Shield rating calculations
- Vulnerability detection
"""

import pytest
import tempfile
from pathlib import Path
from dataclasses import asdict

from shield_analyzer import (
    ErrorHandlingMetrics,
    CircuitBreakerMetrics,
    RetryMetrics,
    TimeoutMetrics,
    BulkheadMetrics,
    DegradationMetrics,
    ObservabilityMetrics,
    HealthCheckMetrics,
    FileResilienceMetrics,
    AegisReport,
    PatternDetector,
    Aegis,
)


# =============================================================================
# FIXTURES
# =============================================================================

@pytest.fixture
def temp_codebase():
    """Create a temporary codebase for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def resilient_codebase(temp_codebase):
    """Create a codebase with good resilience patterns."""
    # File with good error handling
    good_py = Path(temp_codebase) / "good_service.py"
    good_py.write_text('''
import logging
import requests
from tenacity import retry, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)

@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=10))
def fetch_data(url: str) -> dict:
    """Fetch data with retry and timeout."""
    try:
        response = requests.get(url, timeout=30)
        response.raise_for_status()
        logger.info(f"Successfully fetched data from {url}")
        return response.json()
    except requests.RequestException as e:
        logger.error(f"Failed to fetch data: {e}")
        raise

def process_with_fallback(data: dict) -> dict:
    """Process data with fallback."""
    try:
        result = transform(data)
        return result
    except ValueError as e:
        logger.warning(f"Transform failed, using fallback: {e}")
        return {"status": "fallback", "data": None}
    finally:
        logger.debug("Processing complete")

class CircuitBreakerService:
    """Service with circuit breaker pattern."""
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    HALF_OPEN = "HALF_OPEN"
    
    def __init__(self):
        self.state = self.CLOSED
        self.failure_count = 0
        self.failure_threshold = 5
''')
    
    # Health check endpoint
    health_py = Path(temp_codebase) / "health.py"
    health_py.write_text('''
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/health')
def health_check():
    """Liveness probe."""
    return jsonify({"status": "healthy"})

@app.route('/ready')
def readiness_check():
    """Readiness probe."""
    # Check dependencies
    db_ok = check_database()
    cache_ok = check_cache()
    return jsonify({
        "ready": db_ok and cache_ok,
        "database": db_ok,
        "cache": cache_ok
    })
''')
    
    return temp_codebase


@pytest.fixture
def fragile_codebase(temp_codebase):
    """Create a codebase with poor resilience patterns."""
    fragile_py = Path(temp_codebase) / "fragile_service.py"
    fragile_py.write_text('''
import requests

def fetch_data(url):
    # No timeout!
    response = requests.get(url)
    return response.json()

def process_data(data):
    # Bare except - swallows all errors
    try:
        return transform(data)
    except:
        pass

def retry_forever(func):
    # Infinite retry loop - no max attempts
    while True:
        try:
            return func()
        except:
            continue
''')
    
    return temp_codebase


# =============================================================================
# DATA MODEL TESTS
# =============================================================================

class TestErrorHandlingMetrics:
    """Tests for ErrorHandlingMetrics dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        metrics = ErrorHandlingMetrics()
        assert metrics.try_blocks == 0
        assert metrics.bare_excepts == 0
        assert metrics.specificity_ratio == 0.0
    
    def test_custom_values(self):
        """Test custom values."""
        metrics = ErrorHandlingMetrics(
            try_blocks=10,
            except_blocks=10,
            bare_excepts=2,
            specific_excepts=8,
        )
        assert metrics.try_blocks == 10
        assert metrics.bare_excepts == 2


class TestTimeoutMetrics:
    """Tests for TimeoutMetrics dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        metrics = TimeoutMetrics()
        assert metrics.http_timeouts == 0
        assert metrics.missing_timeouts == 0
    
    def test_missing_timeouts_tracking(self):
        """Test tracking of missing timeouts."""
        metrics = TimeoutMetrics(
            http_timeouts=5,
            missing_timeouts=3,
        )
        assert metrics.missing_timeouts == 3


class TestRetryMetrics:
    """Tests for RetryMetrics dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        metrics = RetryMetrics()
        assert metrics.library_imports == []
        assert metrics.exponential_backoff == 0
    
    def test_library_detection(self):
        """Test library import tracking."""
        metrics = RetryMetrics(
            library_imports=['tenacity', 'backoff'],
            retry_decorators=5,
            exponential_backoff=3,
        )
        assert 'tenacity' in metrics.library_imports
        assert metrics.retry_decorators == 5


class TestObservabilityMetrics:
    """Tests for ObservabilityMetrics dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        metrics = ObservabilityMetrics()
        assert metrics.log_statements == 0
        assert metrics.log_levels_used == set()
    
    def test_log_levels_tracking(self):
        """Test log level tracking."""
        metrics = ObservabilityMetrics(
            log_statements=50,
            log_levels_used={'INFO', 'WARNING', 'ERROR'},
            error_logging=10,
        )
        assert 'ERROR' in metrics.log_levels_used
        assert len(metrics.log_levels_used) == 3


class TestFileResilienceMetrics:
    """Tests for FileResilienceMetrics dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        metrics = FileResilienceMetrics(path="test.py", language="python")
        assert metrics.path == "test.py"
        assert metrics.resilience_score == 0.0
    
    def test_nested_metrics(self):
        """Test that nested metrics are initialized."""
        metrics = FileResilienceMetrics(path="test.py", language="python")
        assert isinstance(metrics.error_handling, ErrorHandlingMetrics)
        assert isinstance(metrics.timeouts, TimeoutMetrics)
        assert isinstance(metrics.retries, RetryMetrics)


class TestAegisReport:
    """Tests for AegisReport dataclass."""
    
    def test_default_values(self):
        """Test default values."""
        report = AegisReport(codebase_path="/test", timestamp="2024-01-01")
        assert report.overall_resilience_score == 0.0
        assert report.shield_rating == ""
    
    def test_serialization(self):
        """Test that report can be partially serialized."""
        report = AegisReport(
            codebase_path="/test",
            timestamp="2024-01-01",
            shield_rating="STEEL",
            overall_resilience_score=65.0,
        )
        assert report.shield_rating == "STEEL"


# =============================================================================
# PATTERN DETECTOR TESTS
# =============================================================================

class TestPatternDetector:
    """Tests for PatternDetector class."""
    
    def test_resilience_libraries_defined(self):
        """Test that resilience libraries are defined for multiple languages."""
        assert 'python' in PatternDetector.RESILIENCE_LIBRARIES
        assert 'javascript' in PatternDetector.RESILIENCE_LIBRARIES
        assert 'java' in PatternDetector.RESILIENCE_LIBRARIES
    
    def test_python_libraries_include_common_ones(self):
        """Test that common Python resilience libraries are included."""
        python_libs = PatternDetector.RESILIENCE_LIBRARIES['python']
        
        # Check retry libraries
        assert 'tenacity' in python_libs.get('retry', [])
        
        # Check circuit breaker libraries
        assert 'pybreaker' in python_libs.get('circuit_breaker', [])
    
    def test_detects_tenacity_import(self):
        """Test detection of tenacity import."""
        detector = PatternDetector()
        code = "from tenacity import retry"
        
        libs = detector._detect_resilience_libraries(code, "python")
        assert 'tenacity' in libs
    
    def test_detects_requests_import(self):
        """Test detection of requests library."""
        detector = PatternDetector()
        code = "import requests\nresponse = requests.get(url)"
        
        libs = detector._detect_resilience_libraries(code, "python")
        # requests isn't a resilience library, but we track HTTP clients
        assert isinstance(libs, list)


# =============================================================================
# AEGIS ANALYZER TESTS
# =============================================================================

class TestAegis:
    """Tests for Aegis analyzer class."""
    
    def test_init(self, temp_codebase):
        """Test Aegis initialization."""
        aegis = Aegis(temp_codebase)
        assert aegis.codebase_path == Path(temp_codebase)
    
    def test_library_mode(self, temp_codebase):
        """Test library mode initialization."""
        aegis = Aegis(temp_codebase, library_mode=True)
        assert aegis.library_mode is True
    
    def test_analyze_empty_codebase(self, temp_codebase):
        """Test analysis of empty codebase."""
        aegis = Aegis(temp_codebase)
        report = aegis.analyze()
        
        assert report is not None
        assert report.codebase_path == temp_codebase
    
    def test_analyze_resilient_codebase(self, resilient_codebase):
        """Test analysis of codebase with good patterns."""
        aegis = Aegis(resilient_codebase)
        report = aegis.analyze()
        
        # Should detect some resilience patterns
        assert report.overall_resilience_score >= 0
        assert report.shield_rating != ""
    
    def test_analyze_fragile_codebase(self, fragile_codebase):
        """Test analysis of codebase with poor patterns."""
        aegis = Aegis(fragile_codebase)
        report = aegis.analyze()
        
        # Should detect vulnerabilities
        assert report is not None
        # Fragile code should have lower scores or vulnerabilities
        assert len(report.vulnerabilities) >= 0
    
    def test_detects_retry_patterns(self, resilient_codebase):
        """Test that retry patterns are detected."""
        aegis = Aegis(resilient_codebase)
        report = aegis.analyze()
        
        # Should detect tenacity usage
        assert 'tenacity' in report.resilience_libraries or report.retry_score > 0
    
    def test_detects_timeout_patterns(self, resilient_codebase):
        """Test that timeout patterns are detected."""
        aegis = Aegis(resilient_codebase)
        report = aegis.analyze()
        
        # Should have some timeout score
        assert report.timeout_score >= 0
    
    def test_detects_health_checks(self, resilient_codebase):
        """Test that health check endpoints are detected."""
        aegis = Aegis(resilient_codebase)
        report = aegis.analyze()
        
        # Should detect health endpoints
        assert report.health_check_score >= 0
    
    def test_detects_missing_timeouts(self, fragile_codebase):
        """Test that missing timeouts are flagged."""
        aegis = Aegis(fragile_codebase)
        report = aegis.analyze()
        
        # Should detect missing timeout as vulnerability
        missing_timeout_vulns = [
            v for v in report.vulnerabilities 
            if 'timeout' in v.get('message', '').lower() or v.get('type') == 'missing_timeout'
        ]
        # May or may not detect depending on pattern matching
        assert isinstance(missing_timeout_vulns, list)


# =============================================================================
# SHIELD RATING TESTS
# =============================================================================

class TestShieldRating:
    """Tests for shield rating calculation."""
    
    def test_adamantine_rating(self, temp_codebase):
        """Test ADAMANTINE rating for high scores."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.overall_resilience_score = 85.0
        
        aegis._rate_shield(report)
        assert report.shield_rating == "ADAMANTINE"
    
    def test_steel_rating(self, temp_codebase):
        """Test STEEL rating for good scores."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.overall_resilience_score = 65.0
        
        aegis._rate_shield(report)
        assert report.shield_rating == "STEEL"
    
    def test_bronze_rating(self, temp_codebase):
        """Test BRONZE rating for adequate scores."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.overall_resilience_score = 45.0
        
        aegis._rate_shield(report)
        assert report.shield_rating == "BRONZE"
    
    def test_wood_rating(self, temp_codebase):
        """Test WOOD rating for low scores."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.overall_resilience_score = 25.0
        
        aegis._rate_shield(report)
        assert report.shield_rating == "WOOD"
    
    def test_paper_rating(self, temp_codebase):
        """Test PAPER rating for very low scores."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.overall_resilience_score = 10.0
        
        aegis._rate_shield(report)
        assert report.shield_rating == "PAPER"
    
    def test_too_small_not_rated(self, temp_codebase):
        """Test that too-small codebases keep their rating."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.too_small_to_score = True
        report.shield_rating = "TOO_SMALL"
        
        aegis._rate_shield(report)
        # Should not change the rating
        assert report.shield_rating == "TOO_SMALL"


# =============================================================================
# RECOMMENDATION TESTS
# =============================================================================

class TestRecommendations:
    """Tests for recommendation generation."""
    
    def test_generates_timeout_recommendation(self, temp_codebase):
        """Test that low timeout score generates recommendation."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.timeout_score = 10.0
        report.error_handling_score = 50.0
        report.retry_score = 50.0
        report.circuit_breaker_score = 50.0
        report.observability_score = 50.0
        report.health_check_score = 50.0
        report.bulkhead_score = 50.0
        
        aegis._generate_recommendations(report)
        
        timeout_recs = [r for r in report.recommendations if r['category'] == 'Timeouts']
        assert len(timeout_recs) >= 1
        assert timeout_recs[0]['priority'] == 'CRITICAL'
    
    def test_generates_error_handling_recommendation(self, temp_codebase):
        """Test that low error handling score generates recommendation."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.error_handling_score = 20.0
        report.timeout_score = 50.0
        report.retry_score = 50.0
        report.circuit_breaker_score = 50.0
        report.observability_score = 50.0
        report.health_check_score = 50.0
        report.bulkhead_score = 50.0
        
        aegis._generate_recommendations(report)
        
        eh_recs = [r for r in report.recommendations if r['category'] == 'Error Handling']
        assert len(eh_recs) >= 1
    
    def test_recommendations_sorted_by_priority(self, temp_codebase):
        """Test that recommendations are sorted by priority."""
        aegis = Aegis(temp_codebase)
        report = AegisReport(codebase_path=temp_codebase, timestamp="2024-01-01")
        report.timeout_score = 10.0  # CRITICAL
        report.error_handling_score = 20.0  # HIGH
        report.retry_score = 20.0  # HIGH
        report.circuit_breaker_score = 10.0  # MEDIUM
        report.observability_score = 20.0  # HIGH
        report.health_check_score = 10.0  # MEDIUM
        report.bulkhead_score = 10.0  # LOW
        
        aegis._generate_recommendations(report)
        
        if len(report.recommendations) >= 2:
            priorities = [r['priority'] for r in report.recommendations]
            priority_order = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}
            priority_values = [priority_order.get(p, 99) for p in priorities]
            
            # Should be sorted (ascending priority values)
            assert priority_values == sorted(priority_values)


# =============================================================================
# INTEGRATION TESTS
# =============================================================================

class TestIntegration:
    """Integration tests for the full analysis pipeline."""
    
    def test_full_analysis_resilient(self, resilient_codebase):
        """Test full analysis on resilient codebase."""
        aegis = Aegis(resilient_codebase)
        report = aegis.analyze()
        
        assert report.codebase_path == resilient_codebase
        assert report.timestamp != ""
        assert report.shield_rating in ["ADAMANTINE", "STEEL", "BRONZE", "WOOD", "PAPER", "TOO_SMALL"]
        assert 0 <= report.overall_resilience_score <= 100
    
    def test_full_analysis_fragile(self, fragile_codebase):
        """Test full analysis on fragile codebase."""
        aegis = Aegis(fragile_codebase)
        report = aegis.analyze()
        
        assert report.codebase_path == fragile_codebase
        assert report.shield_rating != ""
    
    def test_save_report(self, resilient_codebase):
        """Test saving report to JSON."""
        aegis = Aegis(resilient_codebase)
        report = aegis.analyze()
        
        output_path = Path(resilient_codebase) / "aegis_report.json"
        saved_path = aegis.save_report(report, str(output_path))
        
        assert Path(saved_path).exists()
        
        import json
        with open(saved_path) as f:
            data = json.load(f)
        
        assert 'shield_rating' in data
        assert 'overall_resilience_score' in data


# =============================================================================
# EDGE CASES
# =============================================================================

class TestEdgeCases:
    """Tests for edge cases."""
    
    def test_empty_directory(self, temp_codebase):
        """Test analysis of empty directory."""
        aegis = Aegis(temp_codebase)
        report = aegis.analyze()
        
        assert report is not None
        assert report.shield_rating in ["PAPER", "TOO_SMALL", ""]
    
    def test_non_python_files(self, temp_codebase):
        """Test handling of non-Python files."""
        # Create a JavaScript file
        js_file = Path(temp_codebase) / "app.js"
        js_file.write_text('''
const axios = require('axios');

async function fetchData(url) {
    try {
        const response = await axios.get(url, { timeout: 5000 });
        return response.data;
    } catch (error) {
        console.error('Fetch failed:', error);
        throw error;
    }
}
''')
        
        aegis = Aegis(temp_codebase)
        report = aegis.analyze()
        
        assert report is not None
    
    def test_syntax_error_in_file(self, temp_codebase):
        """Test handling of files with syntax errors."""
        bad_py = Path(temp_codebase) / "bad_syntax.py"
        bad_py.write_text('''
def broken(
    # Missing closing paren and colon
    pass
''')
        
        aegis = Aegis(temp_codebase)
        # Should not crash
        report = aegis.analyze()
        
        assert report is not None
    
    def test_very_large_file(self, temp_codebase):
        """Test handling of large files."""
        large_py = Path(temp_codebase) / "large.py"
        # Create a file with many functions
        content = "import logging\nlogger = logging.getLogger(__name__)\n\n"
        for i in range(100):
            content += f'''
def function_{i}(x):
    """Function {i}."""
    try:
        logger.info(f"Processing {{x}}")
        return x * {i}
    except Exception as e:
        logger.error(f"Error: {{e}}")
        raise
'''
        large_py.write_text(content)
        
        aegis = Aegis(temp_codebase)
        report = aegis.analyze()
        
        assert report is not None
        assert report.observability_score > 0  # Should detect logging


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
